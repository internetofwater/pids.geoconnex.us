-- Adminer 4.8.1 MySQL 5.7.35 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `yourls` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `yourls`;

DROP TABLE IF EXISTS `yourls_log`;
CREATE TABLE `yourls_log` (
  `click_id` int(11) NOT NULL AUTO_INCREMENT,
  `click_time` datetime NOT NULL,
  `shorturl` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `referrer` varchar(200) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `ip_address` varchar(41) NOT NULL,
  `country_code` char(2) NOT NULL,
  PRIMARY KEY (`click_id`),
  KEY `shorturl` (`shorturl`)
) ENGINE=InnoDB AUTO_INCREMENT=4294 DEFAULT CHARSET=latin1;


SET NAMES utf8mb4;

DROP TABLE IF EXISTS `yourls_options`;
CREATE TABLE `yourls_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`option_id`,`option_name`),
  KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `yourls_options` (`option_id`, `option_name`, `option_value`) VALUES
(1,	'version',	'1.8.2'),
(2,	'db_version',	'506'),
(3,	'next_id',	'2'),
(4,	'active_plugins',	'a:10:{i:0;s:24:\"regex-in-urls/plugin.php\";i:1;s:25:\"redirect-index/plugin.php\";i:2;s:28:\"keep-query-string/plugin.php\";i:3;s:26:\"request-forward/plugin.php\";i:4;s:21:\"always-303/plugin.php\";i:5;s:26:\"bulk-api-import/plugin.php\";i:6;s:34:\"bulk-import-and-shorten/plugin.php\";i:7;s:23:\"change-title/plugin.php\";i:8;s:25:\"sleeky-backend/plugin.php\";i:9;s:27:\"404-if-not-found/plugin.php\";}'),
(5,	'core_version_checks',	'O:8:\"stdClass\":4:{s:15:\"failed_attempts\";i:0;s:12:\"last_attempt\";i:1634228512;s:11:\"last_result\";O:8:\"stdClass\":2:{s:6:\"latest\";s:5:\"1.8.2\";s:6:\"zipurl\";s:56:\"https://api.github.com/repos/YOURLS/YOURLS/zipball/1.8.2\";}s:15:\"version_checked\";s:5:\"1.8.2\";}'),
(6,	'defer_hashing_error',	'1616509581'),
(7,	'redirindex_url',	'https://geoconnex.internetofwater.dev');

DROP TABLE IF EXISTS `yourls_url`;
CREATE TABLE `yourls_url` (
  `keyword` varchar(100) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `url` mediumtext COLLATE utf8mb4_bin NOT NULL,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` varchar(41) COLLATE utf8mb4_bin NOT NULL,
  `clicks` int(10) unsigned NOT NULL,
  PRIMARY KEY (`keyword`),
  KEY `timestamp` (`timestamp`),
  KEY `ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `yourls_url_backup`;
CREATE TABLE `yourls_url_backup` (
  `keyword` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `url` text CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `title` text CHARACTER SET utf8,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` varchar(41) NOT NULL,
  `clicks` int(10) unsigned NOT NULL,
  PRIMARY KEY (`keyword`),
  KEY `timestamp` (`timestamp`),
  KEY `ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- 2021-10-14 16:23:59
